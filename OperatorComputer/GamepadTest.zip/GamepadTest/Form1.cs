﻿using OpenJigWare;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace GamepadTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        float x1 = 115;
        float y1 = 115;
        float x2 = 115;
        float y2 = 115;

        private void Form1_Load(object sender, EventArgs e)
        {
            Ojw.CMessage.Init(txtMessage);
            panel1.Controls.Add(radioButton1);
            panel2.Controls.Add(radioButton2);
            panel3.Controls.Add(radioButton3);

            timer1.Enabled = true;
            radioButton1.Location = new Point( (int)x1, (int)y1);
            radioButton2.Location = new Point((int)x2, (int)y2);
        }

        private float[] m_afAngle = new float[20];

        private Ojw.CJoystick m_CJoy = new Ojw.CJoystick(Ojw.CJoystick._ID_0); // 조이스틱 선언
        private Ojw.CTimer m_CTmr_Joystick = new Ojw.CTimer(); // 조이스틱의 연결을 주기적으로 체크할 타이머

        private void FJoystick_Check_Alive()
        {
            #region Joystick Check

            Color m_colorLive = Color.Green; // 살았을 경우의 색
            Color m_colorDead = Color.Gray; // 죽었을 경우의 색
            if (m_CJoy.IsValid == false)
            {
                #region 조이스틱이 연결되지 않았음을 표시
                if (lbJoystick.ForeColor != m_colorDead)
                {
                    lbJoystick.Text = "Joystick (No Connected)";
                    lbJoystick.ForeColor = m_colorDead;
                }
                #endregion 조이스틱이 연결되지 않았음을 표시

                #region 3초마다 다시 재연결을 하려고 시도
                if (m_CTmr_Joystick.Get() > 3000) // Joystic 이 죽어있다면 체크(3초단위)
                {
                    Ojw.CMessage.Write("Joystick Check again");
                    m_CJoy = new Ojw.CJoystick(Ojw.CJoystick._ID_0);

                    if (m_CJoy.IsValid == false)
                    {
                        Ojw.CMessage.Write("But we can't find a joystick device in here. Check your joystick device");
                        m_CTmr_Joystick.Set(); // 타이머의 카운터를 다시 초기화 한다.
                    }
                    else Ojw.CMessage.Write("Joystick is Connected");
                }
                #endregion 3초마다 다시 재연결을 하려고 시도
            }
            else
            {
                #region 연결 되었음을 표시
                if (lbJoystick.ForeColor != m_colorLive)
                {
                    lbJoystick.Text = "Joystick (Connected)";
                    lbJoystick.ForeColor = m_colorLive;
                }
                #endregion 연결 되었음을 표시
            }
            #endregion Joystick Check
        }

        string DpadKorean = "";
        string DpadEnglish = "";

        private void FJoystick_Check_Data()
        {
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.POVLeft) == true)
            {
                DpadKorean = "왼쪽 ";
                DpadEnglish = "Left ";
            }
            else if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.POVRight) == true)
            {
                DpadKorean = "오른쪽 ";
                DpadEnglish = "Right ";
            } else
            {
                DpadKorean = "";
                DpadEnglish = "";
            }
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.POVUp) == true)
            {
                DpadKorean += "위";
                DpadEnglish += "Up";
            }
            else if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.POVDown) == true)
            {
                DpadKorean += "아래";
                DpadEnglish += "Down";
            }
            if(DpadKorean == "")
            {
                DpadKorean = "안눌림";
                DpadEnglish = "Not pressed";
            }
            
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button4) == true)
            {
                lblY.ForeColor = Color.Red;
            }
            else
            {
                lblY.ForeColor = Color.Black;
            }
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button3) == true)
            {
                lblX.ForeColor = Color.Red;
            }
            else
            {
                lblX.ForeColor = Color.Black;
            }
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button2) == true)
            {
                lblB.ForeColor = Color.Red;
            }
            else
            {
                lblB.ForeColor = Color.Black;
            }
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button1) == true)
            {
                lblA.ForeColor = Color.Red;
            }
            else
            {
                lblA.ForeColor = Color.Black;
            }

            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button5) == true)
            {
                lblLeft.ForeColor = Color.Red;
            }
            else
            {
                lblLeft.ForeColor = Color.Black;
            }
            if (m_CJoy.IsDown(Ojw.CJoystick.PadKey.Button6) == true)
            {
                lblRight.ForeColor = Color.Red;
            }
            else
            {
                lblRight.ForeColor = Color.Black;
            }
            
            label1.Text = DpadKorean + "\r\n" + DpadEnglish;
            radioButton1.Location = new Point((int)(x1 * 1.8 * m_CJoy.dX0),(int)(y1*1.8* m_CJoy.dY0));
            radioButton2.Location = new Point((int)(x2 * 1.8 * m_CJoy.dX1), (int)(y2 * 1.8 * m_CJoy.dY1));
            textBox1.Text = Convert.ToString("X = " + m_CJoy.dX0 + "\r\nY = " + m_CJoy.dY0);
            textBox2.Text = Convert.ToString("X = " + m_CJoy.dX1 + "\r\nY = " + m_CJoy.dY1);
            radioButton3.Location = new Point((int)(168 -m_CJoy.Slide * 168),10);
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            // 조이스틱 정보 갱신
            m_CJoy.Update();
            // 조이스틱이 살아 있는지 체크하는 함수
            FJoystick_Check_Alive();
            // 조이스틱 데이타 체크
            FJoystick_Check_Data();
        }
    }
}
